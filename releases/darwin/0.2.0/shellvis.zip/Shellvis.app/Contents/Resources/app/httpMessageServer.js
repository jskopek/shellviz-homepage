var ee = require('event-emitter');
var express = require('express');
var bodyParser = require('body-parser');
var uuid = require('uuid');

var app = express();
var emitter = ee({});

app.use(bodyParser.urlencoded({ limit: '50mb' }));

app.post('/', function(req, res) {
    var id = req.body.id || uuid.v1();
    var dataStr = req.body.data;
    var data = JSON.parse(dataStr);
    emitter.emit('data', id, data);

    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(id);
});

app.listen(3384);

module.exports = emitter
