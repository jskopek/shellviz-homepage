var shellviz = require('./index.js');
//new shellviz().visualizeAlt([['John', 'Doe', 34], ['Jane', 'Doe', 32]]);
new shellviz().visualize([['John', 'Doe', 34], ['Jane', 'Doe', 32]]);
