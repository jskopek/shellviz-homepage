python setup.py sdist bdist_wheel

twine upload --repository-url https://test.pypi.org/legacy/ dist/*

# to test:
# pip install --index-url https://test.pypi.org/simple/ shellviz

# for real
twine upload dist/*
