var d3 = require('d3');
var c3 = require('c3');
var $ = require('jQuery');
var _ = require('underscore');
var pug = require('pug');
var timeago = require('time-ago')();
var GroupedBarChartDataView = require('./groupedBarChartDataView.js');
var CardDataView = require('./cardDataView.js');
var PieDataView = require('./C3DataViews.js').PieDataView;
var AreaDataView = require('./C3DataViews.js').AreaDataView;
var BarDataView = require('./C3DataViews.js').BarDataView;
var GaugeDataView = require('./C3DataViews.js').GaugeDataView;
var JSONDataView = require('./JSONDataView.js');
var LocationDataView = require('./locationDataView.js');
var ImageDataView = require('./imageDataView.js');
var MarkdownDataView = require('./markdownDataView.js');
var RawDataView = require('./rawDataView.js');
var NumberDataView = require('./numberDataView.js');
var messageServer = require('../httpMessageServer.js');
var path = require('path');

const shell = require('electron').shell;


class PanelView {
    constructor(id, data) {
        this.id = id;
        this.el = document.createElement('div');
        this.el.classList.add('panel-view');
        this.data = data;
        this.mode = this.getDefaultMode();
        this.updatedAt = new Date();
        this.updatedAtTimer = undefined;
        this.dataView = undefined;
    }
    renderTime() {
        $(this.el).find('.updated-at').text(((new Date() - this.updatedAt) < 1000) ? 'Now' : timeago.ago(this.updatedAt))
    }
    render() {
        $(this.el).html(pug.renderFile(path.join(__dirname, '..', 'templates', 'panelView.pug'), {
            pieEnabled: PieDataView.isValid(this.data),
            barEnabled: BarDataView.isValid(this.data),
            groupedBarEnabled: GroupedBarChartDataView.isValid(this.data),
            areaEnabled: AreaDataView.isValid(this.data),
            gaugeEnabled: GaugeDataView.isValid(this.data),
            markdownEnabled: MarkdownDataView.isValid(this.data),
            jsonEnabled: JSONDataView.isValid(this.data),
            locationEnabled: LocationDataView.isValid(this.data),
            cardEnabled: CardDataView.isValid(this.data),
            imageEnabled: ImageDataView.isValid(this.data),
            numberEnabled: NumberDataView.isValid(this.data),
            rawEnabled: RawDataView.isValid(this.data),
            mode: this.mode,
        }));
        this.renderTime();

        $(this.el).find('.mode-buttons button').on('click', function(e) {
            var scrollTop = $(document).scrollTop(); // get the window's scroll position before rendering
            this.mode = $(e.currentTarget).data('mode');
            this.render();
            $(document).scrollTop(scrollTop); // reset scroll position after rendering
        }.bind(this));

        $(this.el).find('button.clear-button').on('click', function(e) { this.remove(); }.bind(this));

        if(this.mode == 'pie') {
            this.dataView = new PieDataView(this.data);
        } else if(this.mode == 'area') {
            this.dataView = new AreaDataView(this.data);
        } else if(this.mode == 'bar') {
            this.dataView = new BarDataView(this.data);
        } else if(this.mode == 'gauge') {
            this.dataView = new GaugeDataView(this.data);
        } else if(this.mode == 'markdown') {
            this.dataView = new MarkdownDataView(this.data);
        } else if(this.mode == 'json') {
            this.dataView = new JSONDataView(this.data);
        } else if(this.mode == 'location') {
            this.dataView = new LocationDataView(this.data);
        } else if(this.mode == 'card') {
            this.dataView = new CardDataView(this.data);
        } else if(this.mode == 'grouped-bar') {
            this.dataView = new GroupedBarChartDataView(this.data);
        } else if(this.mode == 'image') {
            this.dataView = new ImageDataView(this.data);
        } else if(this.mode == 'number') {
            this.dataView = new NumberDataView(this.data);
        } else {
            this.dataView = new RawDataView(this.data);
        }

        $(this.el).find('.data-view').append(this.dataView.el);
        this.dataView.render();

        clearInterval(this.updatedAtTimer);
        this.updatedAtTimer = setInterval(function() { this.renderTime(); }.bind(this), 5000);

        // launch links in external browser
        $(this.el).on('click', 'a[href]', function(event) {
            event.preventDefault();
            shell.openExternal(this.href);
        });
    }
    update(data) {
        this.data = data;

        // if the data is valid for the current data view, update it
        // otherwise, get a new default mode and re-render
        if(this.dataView.constructor.isValid(data)) {
            this.dataView.update(data);
        } else {
            this.mode = this.getDefaultMode();
            this.render();
        }

        this.updatedAt = new Date();
        this.renderTime();
    }
    remove() {
        $(this.el).remove();
        messageServer.emit('remove', this);
    }
    getDefaultMode() {
        if(LocationDataView.isValidStrong(this.data)) {
            return 'location';
        } else if(CardDataView.isValidStrong(this.data)) {
            return 'card';
        } else if(GroupedBarChartDataView.isValid(this.data)) {
            return 'grouped-bar';
        } else if(GaugeDataView.isValid(this.data)) {
            return 'gauge';
        } else if(AreaDataView.isValid(this.data)) {
            return 'area';
        } else if(PieDataView.isValid(this.data)) {
            return 'pie';
        } else if(BarDataView.isValid(this.data)) {
            return 'bar';
        } else if(JSONDataView.isValid(this.data)) {
            return 'json';
        } else if(ImageDataView.isValid(this.data)) {
            return 'image';
        } else if(MarkdownDataView.isValid(this.data)) {
            return 'markdown';
        } else if(LocationDataView.isValidWeak(this.data)) {
            return 'location';
        } else if(NumberDataView.isValid(this.data)) {
            return 'number';
        } else {
            return 'raw';
        }
    }
}

module.exports = PanelView
