from shellviz import visualize

visualize([['John', 'Doe', 34], ['Jane', 'Doe', 32]])
