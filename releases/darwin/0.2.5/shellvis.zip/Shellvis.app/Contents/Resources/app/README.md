# Shellviz

![shellviz](https://github.com/jskopek/shellviz-desktop/blob/master/public/icon.png)

=====

Icon credit: Elvis by Erik Kuroow from the Noun Project

# Building
## OS X

1. Run npm run build:osx
2. Run npm run build:osx:sign
3. Create ZIP file of app and deploy to homepage. This can be done by creating a new release folder and copying the compressed file over, then re-deploying

## OS X Signing

- You first need to run Xcode and make sure there is a cert in the keychain. This comment helps: https://github.com/electron/electron/issues/7476#issuecomment-285464919
- You will likely need to change the properties in the npm script
- I had issues getting the application signed, but running `spctl --master-disable` fixed the issue for me. This comment helps: https://github.com/electron-userland/electron-builder/issues/890#issuecomment-292335476
