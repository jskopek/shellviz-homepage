var ee = require('event-emitter');
var express = require('express');
var bodyParser = require('body-parser');
var uuid = require('uuid');
var compareVersions = require('compare-versions');
var cors = require('cors');

var app = express();
var emitter = ee({});

app.use(bodyParser.urlencoded({ limit: '50mb' }));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(cors());

app.post('/visualize', function(req, res) {
    // check if the library is outdated
    if(isLibraryOutdated(req.body.libraryLanguage, req.body.libraryVersion)) {
        emitter.emit('outdatedLibrary', req.body.libraryLanguage, req.body.libraryVersion);
    }

    // parse and send out the data event
    try {
        var id = req.body.id || uuid.v1();
        var dataStr = req.body.data;
        var data = JSON.parse(dataStr);
        emitter.emit('data', id, data);
    } catch(e) {
        // return error message
        res.status(500).send('There was an error rendering your data');
    }

    // return success
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(id);
});

app.listen(3384);

module.exports = emitter

function isLibraryOutdated(libraryLanguage, libraryVersion) {
    minLibraryVersions = {
        'python': '0.1.2'
    }
    // if no matching library is found, ignore check
    if(!minLibraryVersions[libraryVersion]) {
        return false;
    }
    // if the comparison returns -1, the libraryVersion is older than the minLibraryVersions
    if(compareVersions(libraryVersion, minLibraryVersions[libraryLanguage]) == -1) {
        return true;
    }
    return false;
}
