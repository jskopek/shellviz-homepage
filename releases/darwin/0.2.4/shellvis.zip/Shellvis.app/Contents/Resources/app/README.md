# Shellviz

![shellviz](https://github.com/jskopek/shellviz-desktop/blob/master/public/icon.png)

=====

Icon credit: Elvis by Erik Kuroow from the Noun Project
