var _ = require('underscore');
var jade = require('jade');
var $ = require('jQuery');
var d3 = require('d3');
var c3 = require('c3');
var utils = require('../utils.js');

class GroupedBarChartDataView {
    constructor(data) {
        this.el = document.createElement('div');
        this.data = data;
        this.currentKey = this.getDefaultCurrentKey();
    }
    render() {
        var scrollTop = $(document).scrollTop(); // get the window's scroll position before rendering

        $(this.el).html(jade.renderFile('templates/groupedBarChartDataView.jade', {
            keys: _.keys(this.data[0]),
            currentKey: this.currentKey
        }));

        $(this.el).find('select').on('change', function(e) {
            this.currentKey = $(e.currentTarget).val();
            this.render();
        }.bind(this));

        if(this.currentKey) {
            var aggregatedData = _.pairs(_.countBy(_.pluck(this.data, this.currentKey)));
            var c3Params = this.generateBarC3Params(aggregatedData);
            c3.generate($.extend({}, {bindto: $(this.el).find('.data-aggregated-component').get(0)}, c3Params));
        }

        $(document).scrollTop(scrollTop); // reset scroll position after rendering
    }
    update(data) {
        this.data = data;
        this.render();
    }
    generateBarC3Params(data) {
        return {
            data: {
                columns: [['Value'].concat(_.pluck(data, 1))],
                type: 'bar'
            },
            size: {
                // if there are more than 10 columns, manually set the height based on num columns
                height: data.length > 10 ? data.length * 10 : undefined
            },
            axis: {
                // shows labels on left when there are more than 10 columns
                rotated: data.length > 10, 
                x: {
                    type: 'category',
                    categories: _.pluck(data, 0)
                }
            },
            legend: { show: false }
        };
    }
    getDefaultCurrentKey() {
        // gets the default key to group by
        // looks for the first key that corresponds to a boolean value on first entry; if no boolean values exist, returns the first key
        // that corresponds to a numeric value
        var keyValPairs = _.pairs(_.first(this.data));
        return _.first(_.find(keyValPairs, function(keyVal) { return _.isBoolean(keyVal[1]) })) || _.first(_.find(keyValPairs, function(keyVal) { return _.isNumber(keyVal[1]) }));
    }
    static isValid(data) {
        // used to determine if we can render the GroupedBarChartView, which is in dataViews
        return utils.isArrayOfJSONObjects(data) && (_.unique(_.map(data, function(v) { return _.keys(v).join(','); })).length == 1)
    }
}

module.exports = GroupedBarChartDataView;
