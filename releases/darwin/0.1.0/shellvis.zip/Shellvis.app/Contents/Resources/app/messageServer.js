var ee = require('event-emitter');
var WebSocketServer = require('websocket').server;
var http = require('http');

var emitter = ee({});

var server = http.createServer(function(request, response) {
    response.writeHead(404);
    response.end();
});
server.listen(8080);

wsServer = new WebSocketServer({
    httpServer: server,
    autoAcceptConnections: false
});

wsServer.on('request', function(request) {
    var connection = request.accept();
    connection.on('message', function(message) {
        var dataStr = (message.type === 'utf8') ? message.utf8Data : message.binaryData;
        var data = JSON.parse(dataStr);
        console.log(data);
        emitter.emit('data', data);
    });
});

module.exports = emitter
