import json
import httplib
import urllib

# from websocket import create_connection
#
# def visualize(data):
#     data = json.dumps(data)
#     ws = create_connection("ws://localhost:8080/")
#     ws.send(data)
#     ws.close()
#

def visualize_http(data):
    conn = httplib.HTTPConnection('localhost:8080')
    data_str = urllib.quote(json.dumps(data))
    conn.request('GET', '/?data=%s' % data_str)

a = [9,2,3,4]
visualize_http(a)
