var messageServer = require('./httpMessageServer.js');
var fs = require('fs');
var uuid = require('uuid');

// test data
var data = [
//    [["the",383],["of",285],["to",279],["and",193],["in",154],["he",94],["his",92],["that",87],["a",80],["by",69],["it",67],["is",66],["",64],["as",64],["for",62],["was",62],["not",61],["have",59],["they",54],["with",51],["are",51],["be",48],["who",44],["has",40],["which",38],["one",38],["had",35],["on",33],["I",29],["their",29],["will",28],["but",28],["been",27],["those",26],["him",26],["at",25],["you",24],["them",23],["no",23],["or",23],["there",23],["from",23],["if",22],["when",21],["this",21],["so",20],["would",19],["were",18],["an",18],["\"The",17]],
//    {'latitude': 47.88038, 'longitude': 10.6222475 },
//    [-94, 180],
//    [49.28, -123.12],
    .87,
    287,
    94992332.23,
    10023902309200030032.23,
    [1,1,4,22],
    [21,1,4,22],
//    [['Apples', 3], ['Pears', 10], ['Oranges', 3]],
//    {
//        'Unicorns': 20,
//        'Pumpernickels': 49
//    },
//    [{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Account Managers","name":"Account Manager","has_articles":true,"specialization_of":[],"vector_neighbours":null,"image":"image/upload/v1455562354/miinp6kvpgg1urcbuiyi.jpg","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1455562354/fn67qvxf887vx8dbvuzm.jpg","has_videos":true,"choice_vector":null,"has_education":false,"has_salary":false,"slug":"account-manager","categories":[45,61]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Online Merchants","name":"Online Merchant","has_articles":false,"specialization_of":[],"vector_neighbours":null,"image":"image/upload/v1449085480/career-online-merchant","constraint_vector":null,"onet_id":"13-1199.06","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1449085481/career-online-merchant-banner","has_videos":false,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"online-merchant","categories":[61,42]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Session Musicians","name":"Session Musician","has_articles":false,"specialization_of":[839],"vector_neighbours":null,"image":"image/upload/v1456440040/rkgg642g8czcug0xoaut.jpg","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1456440132/zdd1qrl8tw9qwob7hu5b.jpg","has_videos":true,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"session-musician","categories":[22]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"CEO's","name":"CEO","has_articles":true,"specialization_of":[125],"vector_neighbours":null,"image":"image/upload/v1449085034/career-ceo","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1449085035/career-ceo-banner","has_videos":true,"choice_vector":null,"has_education":false,"has_salary":false,"slug":"ceo","categories":[45]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Organic Farmers","name":"Organic Farmer","has_articles":true,"specialization_of":[50],"vector_neighbours":null,"image":"image/upload/v1449086611/career-organic-farmer","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1449086612/career-organic-farmer-banner","has_videos":true,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"organic-farmer","categories":[39,16]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Music Managers","name":"Music Manager","has_articles":false,"specialization_of":[],"vector_neighbours":null,"image":"image/upload/v1455840512/qqbrmjnr4qt7zldbru6t.jpg","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1455840512/kfvlqih86uamtfpkdnfj.jpg","has_videos":false,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"music-manager","categories":[45,22]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Surgical Technologists","name":"Surgical Technologist","has_articles":false,"specialization_of":[],"vector_neighbours":null,"image":"image/upload/v1449086488/career-surgical-technologist","constraint_vector":null,"onet_id":"29-2055.00","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1449086489/career-surgical-technologist-banner","has_videos":false,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"surgical-technologist","categories":[63]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Music Editors","name":"Music Editor","has_articles":false,"specialization_of":[2],"vector_neighbours":null,"image":"image/upload/v1456267489/xkmls7zmeisbwtmhxgbz.jpg","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1456267390/biqkkegwnqoyk7o7poes.jpg","has_videos":false,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"music-editor","categories":[48,22]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Librettists","name":"Librettist","has_articles":false,"specialization_of":[71],"vector_neighbours":null,"image":"image/upload/v1456278054/w6qv8aiuzvrfsewwdpvw.jpg","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1456277954/ipelsox2lxlulrg1kiut.jpg","has_videos":true,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"librettist","categories":[21,22]},{"status":3,"feature_vector":null,"has_books":false,"plural_name":"Music Critics","name":"Music Critic","has_articles":false,"specialization_of":[61],"vector_neighbours":null,"image":"image/upload/v1456519827/nh7o04r969pcp1pypyqu.jpg","constraint_vector":null,"onet_id":"","is_premium":true,"is_high_demand":false,"banner_image":"image/upload/v1456519828/z9wscm2fnqmt1it885qw.jpg","has_videos":false,"choice_vector":null,"has_education":false,"has_salary":true,"slug":"music-critic","categories":[21,22]}],
//    "Hello world",
//    "http://picalls.com/wp-content/uploads/2015/03/Amazing-night-sky.jpg",
//    fs.readFileSync('sampleMarkdown.md', {encoding:'utf8'})
]

module.exports = {
    'instant': function() {
        data.forEach(function(item) {
            id = uuid.v1();
            messageServer.emit('data', id, item);
        });
    },
    'delayed': function() {
        data.forEach(function(item) {
            setTimeout(function() {
                id = uuid.v1();
                messageServer.emit('data', id, item);
            }, Math.random() * 5000);
        });
    },
    'updating': function() {
        setInterval(function() {
            messageServer.emit('data', 'randomNum', Math.random() * 1000);
            messageServer.emit('data', 'randomPct', Math.random());
        }, 1000);
    }

};
