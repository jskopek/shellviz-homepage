from distutils.core import setup
setup(
  name = 'shellvis',
  packages = ['shellvis'],
  version = '0.1.1',
  description = 'Visualize data graphically directly from the shell',
  author = 'Jean-Marc Skopek',
  author_email = 'jskopek@gmail.com',
  url = 'https://github.com/jskopek/shellvis',
  keywords = ['visualization', 'graphs'],
  classifiers = [],
)
